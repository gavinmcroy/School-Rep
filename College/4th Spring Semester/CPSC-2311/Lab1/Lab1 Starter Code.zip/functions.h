#include <stdio.h>
#include <stdlib.h>

void checkFile(FILE*);

void checkArguments(int);

void checkBraces(FILE*);
