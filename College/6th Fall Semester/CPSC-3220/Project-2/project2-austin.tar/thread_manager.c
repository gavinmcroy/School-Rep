//thread defined variables 
#define THREAD_RUNNABLE 0
#define THREAD_FINISHED 3
#define THREAD_RUNNING 1
#define THREAD_ERROR -1
#define THREAD_LOCKED 1
#define THREAD_PAUSE 2
#define THREAD_UNLOCKED 0
#define THREAD_EXIT 4

#include <stdlib.h>
#include <stdio.h>
#include <ucontext.h>
#include "mythreads.h"

//context variable for thread management
int interruptsAreDisabled = 0;
ucontext_t main_context;

//thread current status
int runningID;
int threadWaiting;
int nextid;

//thread building and conditional use case helper methods
void *linker(thFuncPtr funcPtr, void *argPtr);
void threadChange(int fromID, int toID);
struct Node *threadCurrent();

//Individual thread
struct Node
{
  int id;
  int status; 
  ucontext_t context;
  void *result;
  int lockNum;
  int condNum;
  int queuePos;
  struct Node *next;
};

//methods for managing thread list with priority built-in
struct Node *nodeAdd(ucontext_t context);
struct Node* nodeGet(int id);
struct Node* head;

//methods for maintaining a thread list via linked-list method
int threadPush(ucontext_t context);
int threadDelete(int id);
void threadClose(int id);
void threadRevolve();

//manage thread interrupt status
static void interruptDisable();
static void interruptEnable();

//collect locked status and the
// next position on the conditional variable "queue"
int lockStates[NUM_LOCKS]; 
int condVars[NUM_LOCKS][CONDITIONS_PER_LOCK];

static void interruptDisable() {
  interruptsAreDisabled = 1;
}
static void interruptEnable() {
  interruptsAreDisabled = 0;
}

//Build your thread
void threadInit()
{
  interruptDisable();
  nextid = 0;
  head = NULL;
  threadWaiting = THREAD_ERROR;

  //grab and set your main context for the thread
  getcontext(&main_context);
  main_context.uc_stack.ss_size = STACK_SIZE;
  main_context.uc_stack.ss_flags = 0;
  runningID = threadPush(main_context);
  nodeGet(runningID)->status = THREAD_RUNNING;

  //set all lock conditions for the thread
  int first_iter, second_iter;
  for (first_iter = 0; first_iter < NUM_LOCKS; first_iter++)
  {
    lockStates[first_iter] = THREAD_UNLOCKED;
    for (second_iter = 0; second_iter < CONDITIONS_PER_LOCK; second_iter++)
      condVars[first_iter][second_iter] = 0;
  }
  interruptEnable();
}

//create new thread
//interrupts should be disabled for this process
int threadCreate(thFuncPtr funcPtr, void *argPtr)
{
  interruptDisable();
  ucontext_t targetcontext;
  getcontext(&targetcontext);

  //set your target context size for the new thread - after initialization
  targetcontext.uc_stack.ss_sp = malloc(STACK_SIZE);
	targetcontext.uc_stack.ss_size = STACK_SIZE;
  targetcontext.uc_stack.ss_flags = 0;

  //call helper function to populate linking the new context
  makecontext(&targetcontext, (void (*) (void))linker, 2, funcPtr, argPtr);

  //finally push the new thread to the list and swap to it
  int targetID = threadPush(targetcontext);
  threadChange(runningID, targetID);

  interruptEnable();
  return targetID;
}

//pause thread for interrupt event - yield status
void threadYield()
{
  interruptDisable();

  //set and change what the current thread is doing
  struct Node* targetNode = threadCurrent();
  if (targetNode == NULL) {
    interruptEnable();
    return;
  }

  //make new thread node for list and change over
  struct Node *mynode = nodeGet(runningID);
  threadChange(mynode->id, targetNode->id);
  interruptEnable();
}

//using for joining serveral threads along with status change over
void threadJoin(int thread_id, void **result)
{
  interruptDisable();

  struct Node *node = nodeGet(thread_id);
  //depending on the status, grab the thread from list
  if (node == NULL) {
    interruptEnable();
    return;
  }
  //if the thread is both finished and has exited, set wait status
  else {
    while (node->status != THREAD_FINISHED && node->status != THREAD_EXIT) {
      nodeGet(runningID)->status = THREAD_PAUSE;
      threadWaiting = thread_id;
      interruptEnable();
      threadYield();
      interruptDisable();
    }
    if (result != NULL)
      *result = node->result;
    //after the join process, close the thread node
    threadClose(thread_id);
  }
  interruptEnable();
}

//exit the thread, different from closing
void threadExit(void *result)
{
  interruptDisable();
  //determine run status and leave the thread
  if (runningID == 0)
  {
    struct Node *node = head, *temp;
    //delete and remove anything coorosponding to the thread
    while (node != NULL)
    {
      temp = node->next;
      if (node->id != 0) threadDelete(node->id);
      node = temp;
    }
    exit(0);
  }
  nodeGet(runningID)->status = THREAD_FINISHED;
  nodeGet(runningID)->result = result;
  interruptEnable();
  threadYield();
}

//lock the thread from being used
void threadLock(int lockNum)
{
  interruptDisable();
  while (lockStates[lockNum] == THREAD_LOCKED) {
    interruptEnable();
    threadYield();
    interruptDisable();
  }
  lockStates[lockNum] = THREAD_LOCKED;
  interruptEnable();
}

//unlock the thread so it may be used
void threadUnlock(int lockNum)
{
  interruptDisable();
  lockStates[lockNum] = THREAD_UNLOCKED;
  interruptEnable();
}

//the thread should wait given the condition that it is in possession
//  of a lock
void threadWait(int lockNum, int conditionNum)
{
  interruptDisable();
  if (lockStates[lockNum] != THREAD_LOCKED) {
    fprintf(stderr, "ERROR: ThreadWait called with no lock in possession...");
    exit(THREAD_ERROR);
  }

  //update the thread node linked list
  struct Node *node = nodeGet(runningID);
  node->lockNum = lockNum;
  node->condNum = conditionNum;
  condVars[lockNum][conditionNum]++;
  node->queuePos = condVars[lockNum][conditionNum];

  //update locked status and conditional variable for the current thread list
  lockStates[lockNum] = THREAD_UNLOCKED;
  while (node->queuePos > 0) {
    interruptEnable();
    threadYield();
    interruptDisable();
  }
  node->condNum = THREAD_ERROR;
  node->lockNum = THREAD_ERROR;
  node->queuePos = THREAD_ERROR;
  interruptEnable();
  threadLock(lockNum);
}

//proved the thread signal to allow the queue to update
void threadSignal(int lockNum, int conditionNum)
{
  interruptDisable();
  if (condVars[lockNum][conditionNum] == 0) {
    interruptEnable();
    return;
  }
  //update the conditional variable queue
  condVars[lockNum][conditionNum]--;
  struct Node *node = head;
  while (node != NULL)
  {
    if (node->lockNum == lockNum && node->condNum == conditionNum)
      node->queuePos--;
    node = node->next;
  }
  interruptEnable();
}
//-----------------------HELPER METHODS----------------------//

//this method is used for makeContext() to allow argument linking
void *linker(thFuncPtr funcPtr, void *argPtr)
{
  interruptEnable();
  void *result = (void *)funcPtr(argPtr);
  threadExit(result);
  return result;
}

//this method is to help change over the thread in the list via ID
void threadChange(int fromID, int toID)
{
  if (fromID == toID) return;

  //set thread node pointers used for changeover
  struct Node *fromNode = nodeGet(fromID);
  struct Node *toNode = nodeGet(toID);

  ucontext_t *fromcontext, *tocontext;
  fromcontext = &(fromNode->context);
  tocontext = &(toNode->context);

  //set changeover node status for the new thread
  if (fromNode->status == THREAD_RUNNING)
    fromNode->status = THREAD_RUNNABLE;
  runningID = toID;
  toNode->status = THREAD_RUNNING;

  getcontext(fromcontext);
  swapcontext(fromcontext, tocontext);

  if (toNode->status == THREAD_RUNNING)
    toNode->status = THREAD_RUNNABLE;
  if (fromNode->status == THREAD_RUNNABLE)
    fromNode->status = THREAD_RUNNING;
  runningID = fromID;
}
//---------------------END HELPER METHODS-----------------------//

//------------------------THREAD LIST---------------------------//

//used for selecting what the current thread is
struct Node *threadCurrent()
{
  struct Node *node = head;
  struct Node *currentNode = nodeGet(runningID),
    *nodeIsWaiting = nodeGet(threadWaiting);

  int index = 0;
  //set current thread to the node from waiting list
  if (currentNode->status == THREAD_PAUSE && nodeIsWaiting->status == THREAD_FINISHED) {
    currentNode->status = THREAD_RUNNING;
    node = nodeIsWaiting;
    threadWaiting = THREAD_ERROR;
  } else {
    while (node != NULL)
    {
      if (node->status == THREAD_RUNNABLE ||
        (node->status == THREAD_PAUSE && node->id != runningID)) break;
      else index++;
      node = node->next;
    }
  }
  //rotate the thread linked list
  for (; index >= 0; index--) threadRevolve();
  return node;
}

//used for adding a new thread to the node list
struct Node *nodeAdd(ucontext_t context)
{
  struct Node *node = malloc(sizeof(struct Node));
  node->id = nextid;
  nextid++;
  node->lockNum = THREAD_ERROR;
  node->context = context;
  node->status = THREAD_RUNNABLE;
  node->queuePos = THREAD_ERROR;
  node->condNum = THREAD_ERROR;

  node->next = NULL;
  return node;
}

//pushes the newest thread node to the front of the list
struct Node *pushFront(ucontext_t context)
{
  struct Node *node = nodeAdd(context);
  node->next = head;
  head = node;
  return node;
}

//pushed the oldest thread node to the back of the list
struct Node *pushBack(ucontext_t context)
{
  struct Node *node = nodeAdd(context);
  struct Node *last, *iter = head;
  if (iter == NULL) {
    head = node;
    return node;
  }
  while (iter != NULL)
  {
    last = iter;
    iter = iter->next;
  } last->next = node;
  return node;
}

//push the thread node onto the list
int threadPush(ucontext_t context)
{
  return pushBack(context)->id;
}

//rotate the list as to keep consistency in thread node execution
//used for thread preemtion
void threadRevolve()
{

  if (head == NULL || head->next == NULL) return;

  struct Node *tail = head;
  while (tail != NULL)
  {
    if (tail->next == NULL) break;
    tail = tail->next;
  }
  tail->next = head;
  head = head->next;
  tail->next->next = NULL;
}

//remove the thread node from the linked list, then delete the actual thread
int threadDelete(int id)
{
  struct Node *node = head, *last = NULL;

  if (id != 0)
    free((char *)nodeGet(id)->context.uc_stack.ss_sp);

  if (head->id == id) {
    node = head;
    head = head->next;
    return id;
  } else {
    while (node != NULL)
    {
      if (node->id == id) {
        last->next = node->next;
        return id;
      }
      last = node;
      node = node->next;
    }
  }
  return THREAD_ERROR;
}

//close the thread from the list only
void threadClose(int id)
{
  struct Node* node = nodeGet(id);

  //if the thread has properly exited, free the memory associated with the thread
  if (node->status != THREAD_EXIT && id != 0)
    free((char *)node->context.uc_stack.ss_sp);

  node->queuePos = THREAD_ERROR;
  node->lockNum = THREAD_ERROR;
  node->status = THREAD_EXIT;
  node->condNum = THREAD_ERROR;
}

//grab a specific thread node on the currently running list
struct Node* nodeGet(int id)
{
  struct Node *node = head;
  while (node != NULL)
  {
    if (node->id == id)
      return node;
    node = node->next;
  }
  return NULL;
}
//--------------------------END THREAD LIST-------------------//