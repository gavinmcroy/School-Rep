#include "Cartoon.h"

int main(int argc, char *argv[]) {
    runMainLoop(argc, argv);
    return 0;
}