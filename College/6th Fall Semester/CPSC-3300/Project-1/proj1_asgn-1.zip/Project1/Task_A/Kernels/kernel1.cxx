#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "kernel1.h"

#ifdef ERT_GPU
int gpu_blocks;
int gpu_threads;
#else
#endif
