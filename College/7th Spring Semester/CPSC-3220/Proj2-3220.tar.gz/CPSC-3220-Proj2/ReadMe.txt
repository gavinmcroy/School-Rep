This can be ran two ways. I just did this incase something somehow goes wrong on submission
First method is through cmake 
	1. > cmake CMakeLists.txt
	2. > make
Second method is just by typing make
	1. ./sched <schedule> in.txt out.txt