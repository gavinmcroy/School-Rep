Just from the way this is setup you do need to specify the port for UDP client. The command line 
arguments go as follows

<Server Address/Name> <Echo Word> [<Server Port/Service>] <FileName>
