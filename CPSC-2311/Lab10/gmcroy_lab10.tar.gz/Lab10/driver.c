
/****************************** /
* Gavin McRoy                       *
* CPSC2310 Spring 2021      *
* UserName: gmcroy             *
* Instructor:Dr. Yvon Feaster *
/ *****************************/

#include <stdio.h>

int main(){
    int min = -5;
    int max = 1;
    
    for(int i = min; i<=max; i++){
        printf("%d",i);
    }
    printf("\n");
    return 0;
}
