#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

/************************** /
 * Gavin McRoy
 * CPSC2310 Lab7
 * UserName:  gmcroy
 * Lab Section:  002
/*************************/

int isArithmetic();
int isOddOne(unsigned);

#endif
