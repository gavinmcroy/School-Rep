#include "functions.h"
/************************** /
 * Gavin McRoy                                 
 * CPSC2310 Lab7
 * UserName:  gmcroy
 * Lab Section:  002
/*************************/

int main()
{

    printf("%d\n", isOddOne(128));
    printf("%d\n", isOddOne(64));

    return 0;
}


