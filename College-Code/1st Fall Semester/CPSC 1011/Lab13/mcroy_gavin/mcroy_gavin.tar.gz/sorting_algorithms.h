//
// Created by Gavin Taylor Mcroy on 12/3/2019 AD.
//

#ifndef LAB13_SORTING_ALGORITHMS_H
#define LAB13_SORTING_ALGORITHMS_H

void SelectionSort(int numberArray[], int num);

void InsertionSort(int numberArray[], int num);

void BubbleSort(int numberArray[], int num);

void QuickSort(int low, int high, int numberArray[]);


#endif //LAB13_SORTING_ALGORITHMS_H
