#!/bin/bash
make;
nohup perf stat ./dgmake 8 1024 5 0 & wait;
nohup perf stat ./dgmake 8 2048 5 0 & wait;
nohup perf stat ./dgmake 8 4096 5 0 & wait;
nohup perf stat ./dgmake 4 1024 5 0 & wait;
nohup perf stat ./dgmake 4 2048 5 0 & wait;
nohup perf stat ./dgmake 4 4096 5 0 & wait;
nohup perf stat ./dgmake 2 1024 5 0 & wait;
nohup perf stat ./dgmake 2 2048 5 0 & wait;
nohup perf stat ./dgmake 2 4096 5 0 & wait;
nohup perf stat ./dgmake 1 1024 5 0 & wait;
nohup perf stat ./dgmake 1 2048 5 0 & wait;
nohup perf stat ./dgmake 1 4096 5 0 & wait;               
