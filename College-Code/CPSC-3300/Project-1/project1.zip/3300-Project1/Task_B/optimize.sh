#!/bin/bash
make;
gcc dgemm.c -O2 -Wall -Wextra -o dgmake -fopenmp & wait;
nohup perf stat ./dgmake 4 4096 5 0 & wait;
gcc dgemm.c -O1 -Wall -Wextra -o dgmake -fopenmp & wait;
nohup perf stat ./dgmake 4 4096 5 0 & wait;
