#include <memory>
#include <iostream>
#include <string>
#include "Display.h"

int main(int argc, char *argv[]) {
    init(argc, argv);

    /* TODO KNOWN PROBLEMS:
     * Images are displayed upside down
     * grey scale images are improperly displayed but properly outputted? */
}

