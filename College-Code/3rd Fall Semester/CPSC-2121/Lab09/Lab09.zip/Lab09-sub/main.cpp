#include "Jugs.h"

int main() {
    Jugs jugs;
    jugs.getUserInput();
}
