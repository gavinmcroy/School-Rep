package cpsc3300.project4.simulator.models;

public class RegistersModel {
	private             int[]    registers; // TODO: Identify number of registers to support
	public static final String[] registerNames; // TODO: Identify register names in order

	public int readRegister(byte regAddr) {
		// TODO: return value in register given by index
	}

	public void writeRegister(byte regAddr, int word) {
		// TODO: store value word in register given by index
	}
}
