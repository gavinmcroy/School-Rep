#ifndef _CASSIGNMENT5_H
#define _CASSIGNMENT5_H

#include "../Common/CAssignmentBase.h"

class CSortingMain : public CAssignmentBase {
public:
    ~CSortingMain() override = default;;

    bool DoCompute() override;
};

#endif
